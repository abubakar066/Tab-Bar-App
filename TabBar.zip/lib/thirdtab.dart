import 'package:flutter/material.dart';

class premium extends StatefulWidget {
  const premium({Key? key}) : super(key: key);

  @override
  _premiumState createState() => _premiumState();
}

class _premiumState extends State<premium> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            SizedBox(
              height: 20,
            ),
            Center(
              child: Container(
                width: 320,
                height: 420,
                padding: new EdgeInsets.all(10.0),
                child: Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15.0),
                  ),
                  color: Colors.white,
                  elevation: 10,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "For Real Estate Agencies",
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 20,
                            fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Column(
                                children: [
                                  Text("\$",
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 30,
                                      )),
                                ],
                              ),
                              Column(
                                children: [
                                  Text("",
                                      style: TextStyle(
                                        color: Colors.white,
                                      )),
                                  Text(" 60",
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 40,
                                      )),
                                ],
                              ),
                              Column(
                                children: [
                                  Text("",
                                      style: TextStyle(
                                        color: Colors.white,
                                      )),
                                  Text("",
                                      style: TextStyle(
                                        color: Colors.white,
                                      )),
                                  Text(" /month",
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 20,
                                      )),
                                ],
                              )
                            ],
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      SizedBox(
                        width: 250.0,
                        height: 30.0,
                        child: Divider(
                          color: Colors.grey,
                          thickness: 3.0,
                        ),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      Text(
                        "200 Ad's per month",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 20,
                        ),
                      ),
                      SizedBox(
                        height: 15,
                      ),
                      Text(
                        "Promoted",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 20,
                        ),
                      ),
                      SizedBox(
                        height: 15,
                      ),
                      Text(
                        "Full Control Over Ad's",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 20,
                        ),
                      ),
                      SizedBox(
                        height: 15,
                      ),
                      Text(
                        "Can Upgrade Service Anytime",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 20,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 40,
            ),
            Row(
              children: [
                SizedBox(
                  width: 30,
                ),
                Expanded(
                  child: OutlinedButton(
                    style: ButtonStyle(
                      shape: MaterialStateProperty.all<OutlinedBorder>(
                          StadiumBorder()),
                      side: MaterialStateProperty.resolveWith<BorderSide>(
                          (Set<MaterialState> states) {
                        final Color color =
                            states.contains(MaterialState.pressed)
                                ? Colors.black
                                : Colors.black;
                        return BorderSide(color: color, width: 2);
                      }),
                    ),
                    onPressed: () {},
                    child: Text('SIGN UP'),
                  ),
                ),
                SizedBox(
                  width: 30,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
